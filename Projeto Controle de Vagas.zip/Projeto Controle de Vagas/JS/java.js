
// Quantidade total de vagas do estacionamento
const totalVagas = 20;

// Quantidade de vagas disponíveis
let vagasDisponiveis = 20;

// Lista que vai guardar os veículos
let veiculos = [];

// Pegar os elementos do HTML
const contador = document.getElementById("contador");
const formulario = document.getElementById("formulario");
const lista = document.getElementById("lista-veiculos");

// Mostrar a quantidade de vagas na tela
function atualizarContador() {
    contador.textContent = vagasDisponiveis;
}

// Quando o formulário for enviado
formulario.onsubmit = function(event) {

    // Não deixar a página atualizar sozinha
    event.preventDefault();

    // Pegar as informações digitadas
    let placa = document.getElementById("placa").value;
    let tipo = document.getElementById("tipo").value;
    let proprietario = document.getElementById("proprietario").value;

    
    
    // Verificar se ainda existem vagas
    if (vagasDisponiveis > 0) {

        // Guardar as informações do veículo
        veiculos.push({
            placa: placa,
            tipo: tipo,
            proprietario: proprietario
        });

        // Mostrar o veículo na tela
        lista.innerHTML +=
            "<p>Placa: " + placa +
            " | Tipo: " + tipo +
            " | Proprietário: " + proprietario +
            "</p>";

        // Diminuir uma vaga
        vagasDisponiveis--;

        // Atualizar o contador
        atualizarContador();

        // Limpar o formulário
        formulario.reset();

        alert("Veículo cadastrado com sucesso!");

    } 
    
    // Se não houver vagas
    else {

        alert("Estacionamento lotado!");

    }
};

// Mostrar o contador ao abrir a página
atualizarContador();
